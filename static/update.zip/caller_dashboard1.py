#!/usr/bin/env python3
"""
caller_dashboard1.py — VerityLink AI Dashboard (fixed)
"""
import sys
import zipfile
import json
import threading
import os
from pathlib import Path
from typing import Dict, Any, List
import requests
from datetime import datetime
import platform

# Optional timezone
try:
    from tzlocal import get_localzone
    LOCAL_TZ = get_localzone()
except Exception:
    from zoneinfo import ZoneInfo
    LOCAL_TZ = ZoneInfo("America/Chicago")

from PyQt6.QtGui import QPixmap, QFont, QPainter
from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QPushButton,
    QLabel,
    QTableView,
    QHeaderView,
    QAbstractItemView,
    QFrame,
    QToolButton,
    QTimeEdit,
    QDialog,
    QTextEdit,
    QCheckBox,
    QStackedWidget,
)
from PyQt6.QtCore import (
    Qt,
    QTimer,
    QThread,
    pyqtSignal,
    QAbstractTableModel,
    QPropertyAnimation,
    QEasingCurve,
)

import requests
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox
)
from PyQt6.QtCore import Qt


# -----------------------------
# CONFIG
# -----------------------------
DEFAULT_API_URL = "https://lexi-webhook-hlf9.onrender.com/calls"
STATUS_URL = "https://lexi-webhook-hlf9.onrender.com/status"
TOGGLE_URL = "https://lexi-webhook-hlf9.onrender.com/toggle"
SET_TIME_URL = "https://lexi-webhook-hlf9.onrender.com/set-time-range"
AUTO_REFRESH_MS = 10_000
STATUS_POLL_MS = 5_000
CONFIG_PATH = os.path.expanduser("~/.caller_dashboard_config.json")
SETTINGS_FILE = "agent_settings.json"
SERVER_VERSION_URL = "https://lexi-webhook-hlf9.onrender.com/version.json"
LOCAL_VERSION_FILE = "version.txt"

# -----------------------------
# THEME COLORS
# -----------------------------
BASE_BLACK = "#0a0a0a"
PANEL_BLACK = "#121212"
BORDER_GRAY = "#2a2a2a"
TEXT_MAIN = "#e0e0e0"
TEXT_SUBTLE = "#a0a0a0"
ACCENT_BLUE = "#357DED"
ACCENT_RED = "#b22222"
ACCENT_GREEN = "#2e8b57"

def resource_path(filename: str):
    import sys, os
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, filename)
    return os.path.join(os.path.dirname(__file__), filename)

# -----------------------------
# UPDATER
# -----------------------------
def get_local_version():
    """Read version.txt or return 0.0.0 if missing."""
    if not os.path.exists(LOCAL_VERSION_FILE):
        return "0.0.0"
    return open(LOCAL_VERSION_FILE).read().strip()


def get_server_version():
    """Download version.json from server."""
    return requests.get(SERVER_VERSION_URL).json()


def download_update(url, filename="update.zip"):
    """Download update.zip from server."""
    r = requests.get(url, stream=True)
    with open(filename, "wb") as f:
        for chunk in r.iter_content(1024):
            if chunk:
                f.write(chunk)
    return filename


def apply_update(zip_path):
    """Extract update.zip into the current folder."""
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(".")
    os.remove(zip_path)


def restart_app():
    """Restart the Python program after update."""
    python = sys.executable
    os.execl(python, python, *sys.argv)


def check_for_updates():
    """Compare local and remote versions and auto-update if needed."""
    try:
        local = get_local_version()
        server = get_server_version()

        if local != server["version"]:
            print(f"Updating app: {local} → {server['version']}")

            zipfile_path = download_update(server["url"])
            apply_update(zipfile_path)

            # Save new version
            with open(LOCAL_VERSION_FILE, "w") as f:
                f.write(server["version"])
            
            from datetime import datetime
            with open("last_update.txt", "w") as f:
                f.write(datetime.now().strftime("%B %d, %Y – software update"))

            print("Update applied. Restarting app...")
            restart_app()

    except Exception as e:
        print("Auto-update failed:", e)
        
        
# -----------------------------
# TERMS & ACCEPTANCE
# -----------------------------
def has_accepted_terms():
    if not os.path.exists(CONFIG_PATH):
        return False
    try:
        with open(CONFIG_PATH, "r") as f:
            return json.load(f).get("accepted_terms", False)
    except:
        return False


def save_terms_acceptance():
    with open(CONFIG_PATH, "w") as f:
        json.dump({"accepted_terms": True}, f)


# --- TERMS & ACCEPTANCE (Revised for comprehensive legal structure) ---
# ... (Keep the has_accepted_terms and save_terms_acceptance functions as they are) ...

class TermsDialog(QDialog):
    def __init__(self,  parent=None):
        super().__init__(parent)
        self.setWindowTitle("Terms and Conditions")
        self.setFixedSize(600, 500) # Increased size for longer text
        self.setStyleSheet(f"background-color: {PANEL_BLACK}; color: {TEXT_MAIN};")

        layout = QVBoxLayout(self)
        title = QLabel("Terms & Conditions")
        title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {TEXT_MAIN}; margin-bottom: 10px;")
        layout.addWidget(title)

        terms_text = QTextEdit()
        terms_text.setReadOnly(True)
        terms_text.setStyleSheet(f"""
            background-color: {BASE_BLACK};
            color: {TEXT_SUBTLE};
            border: 1px solid {BORDER_GRAY};
            border-radius: 8px;
            padding: 15px;
            font-size: 11px;
        """)
        
        # --- START OF PROTECTIVE DRAFT TERMS ---
        draft_terms = (
            "**1. Acceptance and License**\n"
            "By using this software, you agree to these terms. VerityLink Communications grants you a limited, non-exclusive, non-transferable license to use the software for its intended purpose only.\n\n"
            
            "**2. User Responsibilities and Compliance**\n"
            "• You warrant that you are authorized to use and monitor all call and data interactions processed by the App.\n"
            "• **Legal Compliance:** You are solely responsible for complying with all local, state, and federal laws regarding call recording, privacy, and data protection (e.g., TCPA, GDPR, CCPA). **VerityLink Communications is not responsible for your compliance failures.**\n\n"
            
            "**3. AI Output Disclaimer (High Risk Mitigation)**\n"
            "• **Fallibility:** You acknowledge that the App utilizes Artificial Intelligence, and its outputs, summaries, or actions are machine-generated and may contain errors, inaccuracies, or incomplete information.\n"
            "• **Verification:** You agree that AI output is **not a substitute for human review or professional judgment**. You are solely responsible for verifying the accuracy of all information generated by the AI agent before acting upon it.\n\n"
            
            "**4. Data Handling and Storage**\n"
            "• The AI system will store call logs and summaries (metadata) necessary for dashboard operation. We will not use personally identifiable content to train proprietary AI models.\n\n"
            
            "**5. Limitation of Liability (CRITICAL)**\n"
            "**THE APP IS PROVIDED 'AS IS' WITHOUT ANY WARRANTIES.**\n"
            "TO THE MAXIMUM EXTENT PERMITTED BY LAW, VERITYLINK COMMUNICATIONS SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES (INCLUDING LOST PROFITS OR DATA LOSS) ARISING FROM THE USE OR INABILITY TO USE THE APP. **OUR TOTAL LIABILITY FOR ANY CLAIM SHALL NOT EXCEED THE AMOUNT PAID BY YOU FOR THE SOFTWARE IN THE LAST SIX (6) MONTHS.**\n\n"
            
            "**6. Indemnification**\n"
            "You agree to defend and indemnify VerityLink Communications against all claims, liabilities, damages, and costs arising out of your violation of these Terms, particularly your failure to comply with data privacy and telecommunications laws."
        )
        # --- END OF PROTECTIVE DRAFT TERMS ---
        
        terms_text.setText(draft_terms)
        layout.addWidget(terms_text)

        btn = QPushButton("Close")
        btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {ACCENT_BLUE};
                color: white;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #4f90ff;
            }}
        """)
        btn.clicked.connect(self.accept_and_save)
        layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignRight)

    def accept_and_save(self):
        save_terms_acceptance()
        self.accept()




LOGIN_URL = "https://lexi-webhook-hlf9.onrender.com/auth/login"
REGISTER_URL = "https://lexi-webhook-hlf9.onrender.com/auth/register"

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        try:
            self.user_name = None
            self.setWindowTitle("Login")
            self.setFixedSize(360, 250)
            self.setStyleSheet("background-color: #121212; color: #e0e0e0;")

            layout = QVBoxLayout(self)
            title = QLabel("Welcome Back")
            title.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px;")
            layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)

            self.username = QLineEdit()
            self.username.setPlaceholderText("Username")
            self.password = QLineEdit()
            self.password.setPlaceholderText("Password")
            self.password.setEchoMode(QLineEdit.EchoMode.Password)

            for w in [self.username, self.password]:
                w.setStyleSheet("background-color: #1e1e1e; padding: 8px; border-radius: 6px;")
                layout.addWidget(w)

            login_btn = QPushButton("Login")
            login_btn.clicked.connect(self.handle_login)
            layout.addWidget(login_btn)

            self.register_link = QPushButton("Create an account")
            self.register_link.setFlat(True)
            self.register_link.setStyleSheet("color: #4da6ff; text-decoration: underline;")
            self.register_link.clicked.connect(self.open_register)
            layout.addWidget(self.register_link, alignment=Qt.AlignmentFlag.AlignCenter)

        except Exception as e:
            QMessageBox.critical(None, "Login Dialog Init Error", str(e))

    def handle_login(self):
        try:
            username = self.username.text().strip()
            password = self.password.text().strip()
            if not username or not password:
                QMessageBox.warning(self, "Missing Info", "Please enter both username and password.")
                return

            try:
                r = requests.post(LOGIN_URL, json={"username": username, "password": password}, timeout=8)
                data = r.json()
            except Exception as e:
                QMessageBox.critical(self, "Connection Error", str(e))
                return

            if data.get("success"):
                self.user_name = data.get("name", username)
                self.accept()
            else:
                QMessageBox.warning(self, "Login Failed", data.get("message", "Invalid login."))

        except Exception as e:
            QMessageBox.critical(self, "Login Error", str(e))

    def open_register(self):
        try:
            reg_dialog = RegisterDialog()
            reg_dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Register Dialog Error", str(e))

class RegisterDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Create Account")
        self.setFixedSize(360, 400) # Keep this size to fit the terms section
        self.setStyleSheet("background-color: #121212; color: #e0e0e0;")

        layout = QVBoxLayout(self)
        title = QLabel("Create a New Account")
        title.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)

        self.name = QLineEdit()
        self.name.setPlaceholderText("Full Name")
        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")
        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)

        for w in [self.name, self.username, self.password]:
            w.setStyleSheet("background-color: #1e1e1e; padding: 8px; border-radius: 6px;")
            layout.addWidget(w)

        # --- Terms and Conditions Section ---
        terms_layout = QHBoxLayout()
        terms_layout.setContentsMargins(0, 10, 0, 10)
        
        self.terms_checkbox = QCheckBox("I Agree to the Terms and Conditions")
        self.terms_checkbox.setStyleSheet("color: #ccc; font-size: 13px;")
        
        self.view_terms_btn = QPushButton("View")
        self.view_terms_btn.setFlat(True)
        self.view_terms_btn.setStyleSheet("color: #4da6ff; text-decoration: underline;")
        # Assumes a TermsDialog class exists and is imported
        self.view_terms_btn.clicked.connect(self.show_terms_dialog) 
        # (Connect to the placeholder method for now)
        
        terms_layout.addWidget(self.terms_checkbox)
        terms_layout.addStretch()
        terms_layout.addWidget(self.view_terms_btn)
        
        layout.addLayout(terms_layout)
        # ----------------------------------------

        self.register_btn = QPushButton("Register")
        self.register_btn.clicked.connect(self.handle_register)
        layout.addWidget(self.register_btn)

    def show_terms_dialog(self):
        """Opens the TermsDialog."""
        try:
            dlg = TermsDialog() # This line requires TermsDialog to be defined above
            dlg.exec()
        except NameError as e:
            QMessageBox.critical(self, "Error", f"Could not find TermsDialog class: {e}. Please ensure it is defined above RegisterDialog.")

    def handle_register(self):
        name = self.name.text().strip()
        username = self.username.text().strip()
        password = self.password.text().strip()
        
        # 1. Check for missing fields first
        if not all([name, username, password]):
            QMessageBox.warning(self, "Missing Info", "Please fill all fields.")
            return

        # 2. Check if terms are accepted (NEW LOGIC)
        if not self.terms_checkbox.isChecked():
            QMessageBox.warning(self, "Agreement Required", "You must agree to the Terms and Conditions before creating an account.")
            return

        # If both checks pass, proceed with registration (blocking request)
        try:
            r = requests.post(REGISTER_URL, json={"name": name, "username": username, "password": password}, timeout=10)
            res = r.json()
            if res.get("success"):
                QMessageBox.information(self, "Success", "Account created successfully!")
                self.accept()
            else:
                QMessageBox.warning(self, "Failed", res.get("message", "Error registering"))
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class LogoLabel(QLabel):
    def __init__(self, pix: QPixmap):
        super().__init__()
        self.pix = pix

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        scaled = self.pix.scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        x = (self.width() - scaled.width()) // 2
        y = (self.height() - scaled.height()) // 2
        painter.drawPixmap(x, y, scaled)


# -----------------------------
# STARTUP SCREEN
# -----------------------------
class StartupScreen(QWidget):
    def __init__(self):
        super().__init__()
        # FIXED: Correct window flag for PyQt6/PySide6
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setStyleSheet(f"background-color: {BASE_BLACK}; color: {TEXT_MAIN};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Load the logo
        logo_path = resource_path("logo6.png")
        print("StartupScreen loading:", logo_path)
        print("Exists?", os.path.exists(logo_path))

        pix = QPixmap(logo_path)
        print("Pixmap valid?", not pix.isNull())

        # If image fails, show text instead
        if pix.isNull():
            logo = QLabel("VerityLink")
            logo.setFont(QFont("Segoe UI", 52, QFont.Weight.Bold))
        else:
            logo = QLabel()
            logo.setPixmap(
                pix.scaled(400, 400, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            )

        logo.setFixedSize(400, 400)
        layout.addWidget(logo, alignment=Qt.AlignmentFlag.AlignCenter)

        # Loading animation
        self.loading = QLabel("Initializing...")
        self.loading.setStyleSheet(f"color: {TEXT_SUBTLE}; font-size: 14px; margin-top: 20px;")
        layout.addWidget(self.loading)

        self.dots = ["", ".", "..", "..."]
        self.i = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        self.timer.start(450)

    def animate(self):
        self.loading.setText(f"Initializing{self.dots[self.i]}")
        self.i = (self.i + 1) % 4


# -----------------------------
# WORKER THREAD
# -----------------------------
class FetchWorker(QThread):
    fetched = pyqtSignal(list)
    error = pyqtSignal(str)

    def __init__(self, url: str, timeout: int = 10):
        super().__init__()
        self.url = url
        self.timeout = timeout

    def run(self):
        try:
            r = requests.get(self.url, timeout=self.timeout)
            r.raise_for_status()
            data = r.json()
            if isinstance(data, list):
                self.fetched.emit(data)
            elif isinstance(data, dict):
                calls = data.get("calls", [])
                self.fetched.emit(calls if isinstance(calls, list) else [data])
        except Exception as e:
            self.error.emit(str(e))

# Insert this new class near the FetchWorker definition
class RegisterWorker(QThread):
    # Signals for communicating results back to the GUI thread
    success = pyqtSignal(str)
    failure = pyqtSignal(str)
    
    def __init__(self, payload):
        super().__init__()
        self.payload = payload

    def run(self):
        try:
            r = requests.post(REGISTER_URL, json=self.payload, timeout=10)
            data = r.json()
            
            if r.status_code == 201 or data.get("success"):
                self.success.emit(self.payload["username"])
            else:
                message = data.get("message", "Registration failed due to an unknown error.")
                self.failure.emit(message)
                
        except requests.exceptions.ConnectionError:
            self.failure.emit("Could not connect to the registration server.")
        except Exception as e:
            self.failure.emit(f"An unexpected error occurred: {e}")

# -----------------------------
# TABLE MODEL (with checkbox)
# -----------------------------
class CallsTableModel(QAbstractTableModel):
    def __init__(self, data=None):
        super().__init__()
        self.columns = ["selected", "name", "phone", "timestamp"]
        self._data = []
        if data:
            self.set_data(data)

    def set_data(self, data: List[Dict[str, str]]):
        self.beginResetModel()
        self._data = [
            {"selected": False,
             "name": d.get("name", "Unknown"),
             "phone": d.get("phone", "Unknown"),
             "timestamp": d.get("timestamp", "")}
            for d in data
        ]
        self.endResetModel()

    def data(self, index, role):
        if not index.isValid():
            return None
        row, col = index.row(), index.column()
        key = self.columns[col]

        # Provide checkbox state for the first column
        if role == Qt.ItemDataRole.CheckStateRole and key == "selected":
            return Qt.CheckState.Checked if self._data[row]["selected"] else Qt.CheckState.Unchecked

        # Display strings for other columns
        if role == Qt.ItemDataRole.DisplayRole:
            if key == "selected":
                return ""  # no text in checkbox column
            return str(self._data[row][key])

        return None

    def rowCount(self, parent=None):
        return len(self._data)

    def columnCount(self, parent=None):
        return len(self.columns)

    def headerData(self, section, orientation, role):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            titles = ["", "Name", "Phone", "Timestamp"]
            if 0 <= section < len(titles):
                return titles[section]
        return None

    def flags(self, index):
        if not index.isValid():
            return Qt.ItemFlag.NoItemFlags
        base = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        # Make first column checkable and editable so clicks toggle
        if index.column() == 0:
            return base | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEditable
        return base | Qt.ItemFlag.ItemIsEditable

    def setData(self, index, value, role):
        if not index.isValid():
            return False
        row, col = index.row(), index.column()
        key = self.columns[col]

        # Accept both CheckStateRole or EditRole with int/bool
        if key == "selected" and (role == Qt.ItemDataRole.CheckStateRole or role == Qt.ItemDataRole.EditRole):
            checked = (value == Qt.CheckState.Checked) or (int(value) == 2) or (value is True)
            self._data[row]["selected"] = bool(checked)
            top_left = self.index(row, col)
            bottom_right = self.index(row, col)
            self.dataChanged.emit(top_left, bottom_right, [Qt.ItemDataRole.CheckStateRole])
            return True

        return False

    def get_checked_rows(self):
        return [r for r in self._data if r["selected"]]

    def remove_checked(self):
        self.beginResetModel()
        self._data = [r for r in self._data if not r["selected"]]
        self.endResetModel()


# -----------------------------
# CALL PAGE
# -----------------------------
class CallAgentPage(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        title = QLabel("Call Agent")
        title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        layout.addWidget(title)

        # ---- Data Table Section ----
        table_frame = QFrame()
        table_frame.setStyleSheet("""
            QFrame {
                background-color: {PANEL_BLACK};
                border-radius: 12px;
                border: 1px solid #333;
                padding: 12px;
            }
            QHeaderView::section {
                background-color: #2b2b2b;
                color: #f0f0f0;
                font-weight: bold;
                border: none;
                padding: 6px;
            }
            QTableView {
                gridline-color: #2b2b2b;
                selection-background-color: #3a3a3a;
                alternate-background-color: #1b1b1b;
            }
        """)

        table_layout = QVBoxLayout(table_frame)
        table_layout.setContentsMargins(8, 8, 8, 8)
        table_layout.setSpacing(10)

        # Table
        self.table = QTableView()
        self.model = CallsTableModel([])
        self.table.setModel(self.model)
        header = self.table.horizontalHeader()
        header.setVisible(True)
        header.setStretchLastSection(True)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        header.setHighlightSections(False)
        header.setStyleSheet("""
            QHeaderView::section {
                background-color: #2b2b2b;
                color: #f5f5f5;
                font-weight: 600;
                font-size: 13px;
                padding: 8px;
                border: none;
                border-bottom: 1px solid #333;
            }
        """)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setShowGrid(False)
        self.table.setColumnWidth(0, 30)

        # Add table to frame
        table_layout.addWidget(self.table)

        # Buttons row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #2b2b2b;  /* dark gray background */
                color: #E0E0E0;             /* light text */
                border-radius: 8px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #2a2a2a;  /* slightly lighter on hover */
            }
            QPushButton:pressed {
                background-color: #070707;  /* darker when pressed */
            }
        """)
        self.refresh_btn.clicked.connect(self.refresh)
        btn_row.addWidget(self.refresh_btn)

        self.del_btn = QPushButton("Delete Checked")
        self.del_btn.setStyleSheet("""
            QPushButton {
                background-color: #b22222;  /* deep red for delete */
                color: #ffffff;
                border-radius: 8px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #c33;  /* lighter red hover */
            }
            QPushButton:pressed {
                background-color: #801818;  /* darker pressed */
            }
        """)
        self.del_btn.clicked.connect(self.delete_checked)
        btn_row.addWidget(self.del_btn)

        # Align buttons to the right
        btn_row.addStretch()

        table_layout.addLayout(btn_row)

        # Info label at bottom
        self.info_label = QLabel("Ready.")
        self.info_label.setStyleSheet("color: #aaa; font-size: 13px;")
        table_layout.addWidget(self.info_label, alignment=Qt.AlignmentFlag.AlignRight)

        # Add the full frame to main layout
        layout.addWidget(table_frame)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(AUTO_REFRESH_MS)
        QTimer.singleShot(300, self.refresh)

    def refresh(self):
        self.info_label.setText("Fetching…")
        worker = FetchWorker(DEFAULT_API_URL)
        worker.fetched.connect(self.on_fetched)
        worker.error.connect(lambda e: self.info_label.setText("Offline"))
        worker.start()
        self.worker = worker

    def on_fetched(self, data):
        normalized = []
        for d in data:
            ts = d.get("timestamp", "")
            try:
                if ts:
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    ts = dt.astimezone(LOCAL_TZ).strftime("%Y-%m-%d %I:%M %p")
            except Exception:
                pass
            normalized.append({
                "name": d.get("name", "Unknown"),
                "phone": d.get("phone", "Unknown"),
                "timestamp": ts
            })
        self.model.set_data(normalized)
        self.info_label.setText(f"Fetched {len(normalized)} calls")

    def delete_checked(self):
        checked = self.model.get_checked_rows()
        if not checked:
            return

        self.info_label.setText(f"Deleting {len(checked)} call(s)...")

        def task():
            try:
                payload = {"calls": checked}
                r = requests.delete(DEFAULT_API_URL, json=payload, timeout=10)
                if r.ok:
                    self.model.remove_checked()
                    self.info_label.setText(f"Deleted {len(checked)} call(s) from server.")
                else:
                    self.info_label.setText(f"Server error: {r.status_code}")
            except Exception as e:
                self.info_label.setText(f"Delete failed: {e}")

        threading.Thread(target=task, daemon=True).start()


class TermsPopup(QDialog):
    """Non-startup terms that can be opened from About page and closed without accepting."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Terms and Conditions")
        self.setFixedSize(500, 400)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setStyleSheet("background-color: #1b1b1b; color: white;")

        layout = QVBoxLayout(self)

        terms_text = QTextEdit()
        terms_text.setReadOnly(True)
        terms_text.setStyleSheet("""
            background-color: #111;
            padding: 10px;
            border: none;
            color: #ddd;
            font-size: 13px;
        """)
        terms_text.setText(
            "Terms & Conditions\n\n"
            "• You are authorized to use this software only for lawful purposes.\n"
            "• The AI system may store call logs and summaries.\n"
            "• The creators are not responsible for misuse.\n"
            "• You agree to comply with privacy and legal regulations.\n"
        )
        layout.addWidget(terms_text)

        close_btn = QPushButton("Close")
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #444;
                color:{TEXT_MAIN};
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)


import os

# -----------------------------
# ABOUT PAGE (clean modern style)
# -----------------------------
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout, QHBoxLayout, QFrame, QPushButton
from PyQt6.QtCore import Qt

class AboutPage(QWidget):
    def __init__(self):
        super().__init__()

        # Helper to read files
        def read_file(path, default):
            return open(path).read().strip() if os.path.exists(path) else default

        version = read_file("version.txt", "1.0.0")
        last_update = read_file("last_update.txt", "—")

        # Outer layout
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(25)

        title = QLabel("About")
        title.setStyleSheet("""
            color: #e0e0e0;
            font-size: 24px;
            font-weight: bold;
        """)
        layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignLeft)

        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setStyleSheet("color: #333; margin: 8px 0;")
        layout.addWidget(divider)

        info_layout = QVBoxLayout()
        info_layout.setSpacing(10)

        def add_row(label_text, value_text):
            row = QHBoxLayout()
            label = QLabel(label_text)
            label.setStyleSheet("color: #a0a0a0; font-weight: 600; min-width: 140px;")
            value = QLabel(value_text)
            value.setStyleSheet("color: #e0e0e0; font-size: 14px;")
            row.addWidget(label)
            row.addWidget(value, 1)
            info_layout.addLayout(row)

        add_row("Application:", "VerityLink")
        add_row("Version:", version)
        add_row("License:", "—")
        add_row("Authorized For:", "—")
        add_row("Created By:", "VerityLink Communications")
        add_row("Last Update:", last_update)
        add_row("Description:", "AI-powered communication dashboard")

        layout.addLayout(info_layout)

        terms_btn = QPushButton("View Terms Conditions")
        terms_btn.setFlat(True)
        terms_btn.setStyleSheet("""
            QPushButton {
                color: #4da6ff;
                font-size: 13px;
                text-align: left;
                padding: 0;
                text-decoration: underline;
                background: transparent;
            }
            QPushButton:hover {
                color: #79c0ff;
            }
        """)
        terms_btn.clicked.connect(self.open_terms_dialog)
        layout.addWidget(terms_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        footer = QLabel("© 2025 VerityLink Communications. All rights reserved.")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer.setStyleSheet("color: #666; font-size: 11px; margin-top: 25px;")
        layout.addWidget(footer)

    def open_terms_dialog(self):
        dlg = TermsDialog(self)
        dlg.exec()



# -----------------------------
# CUSTOMIZE PAGE
# -----------------------------
def load_agent_settings():
     if os.path.exists(SETTINGS_FILE):
         with open(SETTINGS_FILE, "r") as f:
             return json.load(f)
     return {"call_agent_prompt": "", "email_agent_prompt": ""}


def save_agent_settings(settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)


class CustomizeAIPage(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(25)

        self.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 16px;
                font-weight: bold;
            }
            QTextEdit {
                background: #1f1f1f;
                border: 1px solid #3a3a3a;
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
            }
            QPushButton {
                background-color: #4e9eff;
                color: white;
                padding: 10px 16px;
                border-radius: 8px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #74b3ff;
            }
        """)

        # Divider function
        def section(title):
            lbl = QLabel(title)
            line = QFrame()
            line.setFrameShape(QFrame.Shape.HLine)
            line.setFrameShadow(QFrame.Shadow.Sunken)
            line.setStyleSheet("border: 1px solid #3a3a3a;")
            layout.addWidget(lbl)
            layout.addWidget(line)

        # Call Agent Section
        section("Call Agent Personality Prompt")
        self.call_agent_box = QTextEdit()
        self.call_agent_box.setPlaceholderText("Describe how your call agent should speak, act, and respond...")
        layout.addWidget(self.call_agent_box)

        # Email Agent Section (optional)
        section("Email Agent Personality Prompt")
        self.email_agent_box = QTextEdit()
        self.email_agent_box.setPlaceholderText("Describe how your email agent should write, respond, and tone...")
        layout.addWidget(self.email_agent_box)

        # Save Button
        save_button = QPushButton("Save Changes")
        save_button.clicked.connect(self.save)
        layout.addWidget(save_button)

        # Info Label for feedback
        self.info_label = QLabel("")
        self.info_label.setStyleSheet("color: #0f0; font-size: 13px;")  # green for success
        layout.addWidget(self.info_label)

        self.setLayout(layout)

    def save(self):
        import threading, requests, json

        call_prompt = self.call_agent_box.toPlainText()

        # Worker function for API call
        def update_vapi():
            VAPI_AGENT_ID = "709aa056-f7d7-4b79-9a3f-80e8f9949292"
            VAPI_API_KEY = "6b943f96-1b87-4f8b-ae90-172e51568880"
            VAPI_URL = f"https://api.vapi.ai/assistants/{VAPI_AGENT_ID}"

            payload = {"systemPrompt": call_prompt}

            try:
                r = requests.patch(
                    VAPI_URL,
                    headers={
                        "Authorization": f"Bearer {VAPI_API_KEY}",
                        "Content-Type": "application/json"
                    },
                    data=json.dumps(payload),
                    timeout=5
                )
                if r.ok:
                    self.info_label.setText("Call agent updated on Vapi ✅")
                else:
                    self.info_label.setText(f"Failed to update: {r.status_code}")
            except Exception as e:
                self.info_label.setText(f"Error updating Vapi: {e}")

        threading.Thread(target=update_vapi, daemon=True).start()





class MainWindow(QWidget):
    SIDEBAR_EXPANDED_WIDTH = 220
    SIDEBAR_COLLAPSED_WIDTH = 50

    def __init__(self, user_name):
        super().__init__()
        self.setWindowTitle("VerityLink AI Dashboard")
        self.resize(1100, 700)
        self.user_name = user_name
        self.init_ui()
        # Initialize sidebar animation
        self.sidebar_expanded = True
        self.sidebar_anim = QPropertyAnimation(self.sidebar, b"minimumWidth")
        self.sidebar_anim.setDuration(250)
        self.sidebar_anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self.sidebar_anim.finished.connect(self._on_sidebar_anim_finished)

        
    def init_ui(self):
        # Main horizontal layout for sidebar, content, right panel
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # --- Sidebar ---
        self.sidebar = QFrame()
        self.sidebar.setMinimumWidth(self.SIDEBAR_EXPANDED_WIDTH)
        self.sidebar.setMaximumWidth(self.SIDEBAR_EXPANDED_WIDTH)
        self.sidebar.setStyleSheet("background:#1e1e1e;")

        sb = QVBoxLayout(self.sidebar)
        sb.setContentsMargins(10, 10, 10, 10)
        sb.setSpacing(8)

        self.toggle_side = QToolButton()
        self.toggle_side.setText("☰")
        self.toggle_side.setStyleSheet("color:white; font-size:18px;")
        self.toggle_side.setFixedSize(36, 36)
        self.toggle_side.clicked.connect(self.toggle_sidebar)
        sb.addWidget(self.toggle_side, alignment=Qt.AlignmentFlag.AlignLeft)

        # --- Sidebar buttons ---
        self.btn_call = QPushButton("Call Agent")
        self.btn_email = QPushButton("Email Agent")
        self.btn_draft = QPushButton("Customize AI")
        self.btn_about = QPushButton("About")

        for btn in [self.btn_call, self.btn_draft, self.btn_about]:
            btn.setStyleSheet("background:#2b2b2b; color:white;")
            sb.addWidget(btn)
            
        # --- Connect sidebar buttons ---
        self.btn_call.clicked.connect(lambda: self.stack.setCurrentWidget(self.call_page))
        self.btn_email.clicked.connect(lambda: QMessageBox.information(self, "Email Agent", "Email Agent page not implemented yet."))
        self.btn_draft.clicked.connect(lambda: self.stack.setCurrentWidget(self.customize_page))
        self.btn_about.clicked.connect(lambda: self.stack.setCurrentWidget(self.about_page))


        for btn in [self.btn_call, self.btn_email, self.btn_draft, self.btn_about]:
            btn.setStyleSheet("background:#2b2b2b; color:white;")
            btn.setMinimumHeight(36)
            sb.addWidget(btn)

        sb.addStretch()
        content_layout.addWidget(self.sidebar)

        # --- Pages ---
        self.stack = QStackedWidget()
        self.call_page = CallAgentPage()
        self.about_page = AboutPage()
        self.customize_page = CustomizeAIPage()
        self.stack.addWidget(self.call_page)
        self.stack.addWidget(self.about_page)
        self.stack.addWidget(self.customize_page)
        content_layout.addWidget(self.stack, 1)

        # --- Right Panel ---
        self.right_panel = QFrame()
        self.right_panel.setMinimumWidth(250)
        self.right_panel.setStyleSheet("background:#181818;")
        r = QVBoxLayout(self.right_panel)
        r.setContentsMargins(12, 12, 12, 12)
        r.addSpacing(12)

        self.status_label = QLabel("Server: Checking…")
        r.addWidget(self.status_label)

        self.toggle_btn = QPushButton("OFF")
        self.toggle_btn.setFixedHeight(44)
        self.toggle_btn.clicked.connect(self.toggle_bot)
        r.addWidget(self.toggle_btn)

        r.addSpacing(20)
        
        # --- Tips box (modern style, fixed background + text visibility) ---
        tips_box = QFrame()
        tips_box.setObjectName("TipsCard")
        tips_box.setStyleSheet("""
            QFrame#TipsCard {
                background-color: #1f1f1f;
                border: 1px solid #2e2e2e;
                border-radius: 12px;
            }
            QLabel {
                background: transparent;
            }
            QLabel#TipsHeader {
                color: #e0e0e0;
                font-size: 15px;
                font-weight: 600;
            }
            QLabel#TipsBody {
                color: #d8d8d8;
                font-size: 13px;
                line-height: 1.4em;
            }
            QLabel#TipsFooter {
                color: #aaaaaa;
                font-size: 11px;
                margin-top: 8px;
            }
        """)

        tips_layout = QVBoxLayout(tips_box)
        tips_layout.setContentsMargins(14, 12, 14, 12)
        tips_layout.setSpacing(6)

        # Header
        tips_header = QLabel("Quick Help", tips_box)
        tips_header.setObjectName("TipsHeader")
        tips_layout.addWidget(tips_header)

        # Body
        tips_body = QLabel(
            "If the server appears offline:\n"
            "• Wait a few seconds, then refresh.\n"
            "• Check your internet connection.\n"
            "• Restart the dashboard if issue persists."
        )
        tips_body.setObjectName("TipsBody")
        tips_body.setWordWrap(True)
        tips_body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        tips_layout.addWidget(tips_body)

        # Divider
        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setStyleSheet("color: #333; margin: 6px 0;")
        tips_layout.addWidget(divider)

        # Footer
        tips_footer = QLabel("📞 Support: 403-775-7197  •\n      9 AM – 5 PM, 7 days/week")
        tips_footer.setObjectName("TipsFooter")
        tips_footer.setWordWrap(True)
        tips_layout.addWidget(tips_footer)


        r.addWidget(tips_box)
        r.addStretch()
        r.addWidget(QLabel("VerityLink, 2025", alignment=Qt.AlignmentFlag.AlignRight))
        content_layout.addWidget(self.right_panel)

        # --- Welcome banner (spans full width) ---
        top_banner = QFrame()
        top_banner.setStyleSheet("background:#111; border-bottom: 1px solid #333;")
        top_banner.setFixedHeight(60)

        banner_layout = QVBoxLayout(top_banner)
        banner_layout.setContentsMargins(0, 0, 0, 0)
        banner_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        welcome_label = QLabel(f"Welcome, {self.user_name}!", top_banner)
        welcome_label.setStyleSheet("color: #e0e0e0; font-size: 18px; font-weight: bold;")
        banner_layout.addWidget(welcome_label)

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0,0,0,0)
        self.main_layout.setSpacing(0)
        self.main_layout.addWidget(top_banner)
        self.main_layout.addLayout(content_layout)


    def toggle_sidebar(self):
        if self.sidebar_anim.state() == self.sidebar_anim.State.Running:
            self.sidebar_anim.stop()

        if self.sidebar_expanded:
            self.sidebar_anim.setStartValue(self.SIDEBAR_EXPANDED_WIDTH)
            self.sidebar_anim.setEndValue(self.SIDEBAR_COLLAPSED_WIDTH)
            self.sidebar_anim.start()
            self.sidebar_expanded = False
        else:
            for w in [self.btn_call, self.btn_email, self.btn_draft, self.btn_about]:
                w.show()
            self.sidebar_anim.setStartValue(self.SIDEBAR_COLLAPSED_WIDTH)
            self.sidebar_anim.setEndValue(self.SIDEBAR_EXPANDED_WIDTH)
            self.sidebar_anim.start()
            self.sidebar_expanded = True

    def _on_sidebar_anim_finished(self):
        if not self.sidebar_expanded:
            for w in [self.btn_call, self.btn_email, self.btn_draft, self.btn_about]:
                w.hide()
            self.sidebar.setMinimumWidth(self.SIDEBAR_COLLAPSED_WIDTH)
            self.sidebar.setMaximumWidth(self.SIDEBAR_COLLAPSED_WIDTH)
        else:
            self.sidebar.setMinimumWidth(self.SIDEBAR_EXPANDED_WIDTH)
            self.sidebar.setMaximumWidth(self.SIDEBAR_EXPANDED_WIDTH)

        self.call_page.updateGeometry()
        self.main_layout.update()

    def toggle_bot(self):
        on = self.toggle_btn.text() == "OFF"
        self.set_toggle_ui(on)
        threading.Thread(target=self._post_toggle, args=(on,), daemon=True).start()

    def _post_toggle(self, state):
        try:
            requests.post(TOGGLE_URL, json={"active": state}, timeout=5)
        except Exception:
            pass

    def set_toggle_ui(self, on):
        if on:
            self.toggle_btn.setText("ON")
            self.toggle_btn.setStyleSheet("background:#2e8b57; color:white;")
        else:
            self.toggle_btn.setText("OFF")
            self.toggle_btn.setStyleSheet("background:#b22222; color:white;")

    def poll_status(self):
        def task():
            try:
                r = requests.get(STATUS_URL, timeout=3)
                if r.ok:
                    j = r.json()
                    active = j.get("bot_active", False)
                    self.status_label.setText(f"Server: Connected | Bot: {'ON' if active else 'OFF'}")
                    self.set_toggle_ui(active)
                else:
                    self.status_label.setText("Server: Error")
            except Exception:
                self.status_label.setText("Server: Offline")
                self.set_toggle_ui(False)
        threading.Thread(target=task, daemon=True).start()

    def open_dashboard(self, user_name, token=None):
        self.dashboard = MainWindow(user_name=user_name)
        self.dashboard.show()
        self.close()

# -----------------------------
# MAIN
# -----------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)

    # === GLOBAL STYLESHEET ===
    app.setStyleSheet(f"""
        QWidget {{
            background-color: {BASE_BLACK};
            color: {TEXT_MAIN};
            font-family: 'Segoe UI';
        }}

        QLabel {{
            color: {TEXT_MAIN};
        }}

        /* === UNIVERSAL BUTTON STYLING === */
        QPushButton, QToolButton {{
            background-color: #2b2b2b;
            color: {TEXT_MAIN};
            border: 1px solid {BORDER_GRAY};
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.15s ease-in-out;
        }}

        QPushButton:hover, QToolButton:hover {{
            background-color: #3c3c3c;
            border: 1px solid #4a4a4a;
            color: white;
        }}

        QPushButton:pressed, QToolButton:pressed {{
            background-color: #1a1a1a;
            border: 1px solid #555555;
            color: #d0d0d0;
        }}

        /* === SIDEBAR SPECIFIC BUTTONS === */
        QWidget#Sidebar QPushButton {{
            background-color: #1a1a1a;
            border: none;
            text-align: left;
            padding: 10px 20px;
        }}
        QWidget#Sidebar QPushButton:hover {{
            background-color: #2c2c2c;
            color: {ACCENT_BLUE};
        }}
        QWidget#Sidebar QPushButton:pressed {{
            background-color: #101010;
        }}

        /* === REFRESH / ACTION BUTTONS === */
        QPushButton#refreshButton {{
            background-color: #2b2b2b;
            border: 1px solid #3a3a3a;
        }}
        QPushButton#refreshButton:hover {{
            background-color: #3a3a3a;
            color: {ACCENT_BLUE};
        }}

        QLineEdit, QTextEdit {{
            background-color: {PANEL_BLACK};
            color: {TEXT_MAIN};
            border: 1px solid {BORDER_GRAY};
            border-radius: 6px;
            padding: 6px;
        }}

        QTableView {{
            background-color: {PANEL_BLACK};
            alternate-background-color: #0f0f0f;
            color: {TEXT_MAIN};
            gridline-color: {BORDER_GRAY};
            selection-background-color: #303030;
            selection-color: white;
        }}
    """)

  


    # --- STARTUP SCREEN ---
    startup = StartupScreen()
    startup.resize(1100, 700)
    startup.show()

    def proceed_to_login():
        # Keep reference to login dialog
        login_dialog = LoginDialog()
        if login_dialog.exec() == QDialog.DialogCode.Accepted:
            # Login successful, open main window
            main_window = MainWindow(user_name=login_dialog.user_name)
            main_window.show()
            # Close startup screen
            startup.close()
            # Keep reference alive
            app.main_window = main_window
        else:
            # Login canceled
            startup.close()
            sys.exit(0)

    # Launch login after short splash delay
    QTimer.singleShot(1500, proceed_to_login)

    sys.exit(app.exec())

















